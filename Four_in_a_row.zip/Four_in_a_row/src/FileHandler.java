import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class FileHandler {
	
	
	
	
	public void createFile() {
		 try {
		      File file = new File("result.txt");
		      if (file.createNewFile()) {
//		        System.out.println("File created: " + file.getName());
		      } else {
//		        System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	
	public void saveResult() {
		
		PrintStream standard_out = System.out;
		try {
			System.setOut(new PrintStream(new FileOutputStream("result.txt")));
//			game.winnerOrDraw();
		} catch (FileNotFoundException e) {
			System.setOut(standard_out);
			e.printStackTrace();
		}
	}
	
	

}
