import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class Game {
	private Player player1;
	private Player player2;
	private Box box;
	private int turn = 1;
	private String wrongColumn;
	
	public Game() {
		FileHandler file = new FileHandler();
		Scanner scanner = new Scanner(System.in);
		initializeGame(scanner, file);
		playGame(scanner);
		endGame(file);
		scanner.close();
	}
	
//level 1-------------------------------------
	public void initializeGame(Scanner scanner, FileHandler file) {
		createPlayers(scanner);
		createBox(); 
		file.createFile();
	}
	
	public void playGame(Scanner scanner) {
		printFieldState();
		gameOngoing(scanner);
	}
	
	public void endGame(FileHandler file) {
		winnerOrDraw();
		saveResult();
	}
	//---------------------------------------------
	
	// Level 2 !!!!------------------
	
	public void createPlayers(Scanner scanner) {
			this.player1 = new Player(scanner);
			this.player1.readName();
			this.player1.chooseSymbol();
			
			this.player2 = new Player(scanner);
			this.player2.readName();
			this.player2.chooseSymbol();
	}
	
	public void createBox() {
		this.box = new Box();
	}
	
	public void createFile(FileHandler file) {
		file.createFile();
	}
	
	public void printFieldState() {
		printIfInvalidTurn();
		printField();
		printTurnState(this.player1, this.player2);
	}
	
	public void printIfInvalidTurn() {
		
		if (player1.getWrongTurn() != null) {
			System.out.println(player1.getWrongTurn());
			player1.setWrongTurn();
		}else if (player2.getWrongTurn() != null){
			System.out.println(player2.getWrongTurn());
			player2.setWrongTurn();
		}
	}
	
	public void printField() {
		
		System.out.println("\n 1 2 3 4 5 6 7");
		
		for (int i = 0; i < this.box.getTile().length; i++) {
			for (int j = 0; j < this.box.getTile()[i].length; j++) {
				System.out.print("|");
				
				if (this.box.getTile()[i][j].getTileDisc() == null) {
					
					System.out.print(" ");
				}else {
					System.out.print(this.box.getTile()[i][j].getTileDisc().getChar());
				}
			}
			System.out.println("|");
		}
		for (int i = 0; i < 15; i++) {
			System.out.print("-");
		}
		System.out.println("\n 1 2 3 4 5 6 7\n");
	}
	
	public void printTurnState(Player player1,Player player2) {
		
		if (this.turn %2 != 0) {
			System.out.print(player1.getName() + " (Turn" + this.turn + "): ");
		} else {
			System.out.print(player2.getName() + " (Turn" + this.turn + "): ");
		}
	}
	
	public void playerTurn(Scanner scanner) {
		
		
		if (this.turn %2 != 0) {
			this.wrongColumn = player1.chooseColumn(scanner);
			while (this.wrongColumn != null) {
				printFieldState();
				scanner.nextLine();
				this.wrongColumn = player1.chooseColumn(scanner);
			}
			this.box.update(this.player1);
		}else {
			this.wrongColumn = player2.chooseColumn(scanner);
			while (this.wrongColumn != null) {
				printFieldState();
				scanner.nextLine();
				this.wrongColumn = player2.chooseColumn(scanner);
			}
			this.box.update(this.player2);
		}
		if (box.getIsTileLeft()) {
			this.turn++;
		}
	}
	
	public void gameOngoing(Scanner scanner) {
		while (this.box.getValidTurn()) {
			
			if (this.box.getIsTileLeft() == false) {
				this.player1.isWrongTurn();
				printFieldState();
				this.box.resetTileLeft();
			}else {
				playerTurn(scanner);
				if (this.box.getIsTileLeft()) {
					printFieldState();
				}
				this.box.checkIfWinner(this.player1, this.player2);
				this.box.checkMaxTurn(this.turn, this.player1, this.player2);
			}
		}
	}
	
	public void printWinner() {
		printField();
		System.out.println("\nWinner after " + this.turn + " turns: " + player1.getName() + "\n");
	}
	
	public void printDraw() {
		printField();
		System.out.println("\nGame over! Draw!");
	}
	
	public void winnerOrDraw() {
		
		if (box.getWinner()== false) {
			printWinner();
		}else if(box.getFieldFull() == false) {
			printDraw();
		}
	}
	
	public void saveResult() {
		
		PrintStream standard_out = System.out;
		try {
			System.setOut(new PrintStream(new FileOutputStream("result.txt")));
			winnerOrDraw();
		} catch (FileNotFoundException e) {
			System.setOut(standard_out);
			e.printStackTrace();
		}
	}
	
	//-----------------------------------------------------

}
