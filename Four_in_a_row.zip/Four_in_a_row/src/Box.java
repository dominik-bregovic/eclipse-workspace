
public class Box {
	private Tile[][] tiles = new Tile [6][7];
	private boolean validTurn = true;
	private boolean isTileLeft = true;
	private boolean winner = true;
	private boolean fieldFull = true;
	
	public Box() {
		
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				this.tiles[i][j] = new Tile();
			}
		}
	}
	
	
	//have to do a check for chosen Tiles for the 6 rows
	public void update(Player player) {
			if (this.tiles[5][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[5][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else if (this.tiles[4][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[4][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else if (this.tiles[3][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[3][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else if (this.tiles[2][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[2][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else if (this.tiles[1][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[1][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else if (this.tiles[0][player.getColumn() - 1].getTileDisc() == null) {
				this.tiles[0][player.getColumn() - 1].setTileDisc(player.getPlayerDisc());
			}else {
				this.isTileLeft = false;
			}
	}
	
	public void checkMaxTurn(int turn, Player player1, Player player2) {
		if (turn == 43) {
			this.validTurn = false;
			this.fieldFull = false;
			player1 = null;
			player2 = null;
		}
	}
	
	public void checkIfWinner(Player player1, Player player2) {
		// to change the necessary discs needed for winning
		// for 2 discs: a=b=c;
		// for 3 discs : c=b;
		int a = 1; int b = 2; int c = 3;
		
		checkHorizontal(player1, player2, a, b, c);
		checkVertikal(player1, player2, a, b, c);
		checkLeftDiagonal(player1, player2, a, b, c);
		checkRightDiagonal(player1, player2, a, b, c);

	}
	
	
	public void checkHorizontal(Player player1, Player player2, int a, int b, int c) {
		
		//	Horizontal
		
		//Player1
		for(int i = 0; i <= 5; i++) {
			for(int j = 0; j <= 3; j++){
				if(this.tiles[i][j].getTileDisc() == player1.getPlayerDisc() &&
					this.tiles[i][j+a].getTileDisc() == player1.getPlayerDisc() &&
					this.tiles[i][j+b].getTileDisc() == player1.getPlayerDisc() &&
					this.tiles[i][j+c].getTileDisc() == player1.getPlayerDisc()) {
					
					this.validTurn = false;
					this.winner = false;
				}
			}
		}
		//Player2
		for(int i = 0; i <= 5; i++) {
			for(int j = 0; j <= 3; j++){
				if(this.tiles[i][j].getTileDisc() == player2.getPlayerDisc() &&
					this.tiles[i][j+a].getTileDisc() == player2.getPlayerDisc() &&
					this.tiles[i][j+b].getTileDisc() == player2.getPlayerDisc() &&
					this.tiles[i][j+c].getTileDisc() == player2.getPlayerDisc()) {
					
					this.validTurn = false;
					this.winner = false;
				}
			}
		}	
	}
	
	public void checkVertikal(Player player1, Player player2, int a, int b, int c) {
			
			
			//Player1
			for(int i = 0; i <= 2; i++) {
				for(int j = 0; j <= 6; j++){
					if(this.tiles[i][j].getTileDisc() == player1.getPlayerDisc() &&
						this.tiles[i+a][j].getTileDisc() == player1.getPlayerDisc() &&
						this.tiles[i+b][j].getTileDisc() == player1.getPlayerDisc() &&
						this.tiles[i+c][j].getTileDisc() ==player1.getPlayerDisc()) {
						
						this.validTurn = false;
						this.winner = false;
					}
				}
			}
			//Player2
			for(int i = 0; i <= 2; i++) {
				for(int j = 0; j <= 6; j++){
					if(this.tiles[i][j].getTileDisc() == player2.getPlayerDisc() &&
						this.tiles[i+a][j].getTileDisc() == player2.getPlayerDisc() &&
						this.tiles[i+b][j].getTileDisc() == player2.getPlayerDisc() &&
						this.tiles[i+c][j].getTileDisc() == player2.getPlayerDisc()) {
						
						this.validTurn = false;
						this.winner = false;
					}
				}
			}
	}
	
	public void checkLeftDiagonal(Player player1, Player player2, int a, int b, int c) {
		
		//check diagonal to the right hand side
			
			//Player1
			for(int i = 0; i < 3; i++){
				for(int j = 6; j > 2; j--){
					if(tiles[i][j].getTileDisc() == player1.getPlayerDisc() &&
						tiles[i+a][j-a].getTileDisc() == player1.getPlayerDisc() &&
						tiles[i+b][j-b].getTileDisc() == player1.getPlayerDisc() &&
						tiles[i+c][j-c].getTileDisc() == player1.getPlayerDisc()) {
						
						this.validTurn = false;
						this.winner = false;
					}
				}
			}
			//Player2
			for(int i = 0; i < 3; i++){
				for(int j = 6; j > 2; j--){
					if(tiles[i][j].getTileDisc() == player2.getPlayerDisc() &&
						tiles[i+a][j-a].getTileDisc() == player2.getPlayerDisc() &&
						tiles[i+b][j-b].getTileDisc() == player2.getPlayerDisc() &&
						tiles[i+c][j-c].getTileDisc() == player2.getPlayerDisc()) {
						
						this.validTurn = false;
						this.winner = false;
					}
				}
			}
	}
	
	public void checkRightDiagonal(Player player1, Player player2, int a, int b, int c) {
		
		//check diagonal to the left hand side
		
		//Player1
		for(int i = 0; i < 3; i++){
		    for(int j = 0; j < 4; j++){
		        if(tiles[i][j].getTileDisc() == player1.getPlayerDisc() &&
		        	tiles[i+a][j+a].getTileDisc() == player1.getPlayerDisc() &&
		        	tiles[i+b][j+b].getTileDisc() == player1.getPlayerDisc() &&
		       		tiles[i+c][j+c].getTileDisc() == player1.getPlayerDisc()) {
		        	
		        	this.validTurn = false;
		        	this.winner = false;
		        }
		    }
		}
		
		//Player2
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 4; j++){
				if(tiles[i][j].getTileDisc() == player2.getPlayerDisc() &&
					tiles[i+1][j+1].getTileDisc() == player2.getPlayerDisc() &&
					tiles[i+2][j+2].getTileDisc() == player2.getPlayerDisc() &&
					tiles[i+3][j+3].getTileDisc() == player2.getPlayerDisc()) {
					
					this.validTurn = false;
					this.winner = false;
				}
			}
		}
	}
	
	
	public boolean getValidTurn() {
		return this.validTurn;
	}
	
	public boolean getIsTileLeft() {
		return this.isTileLeft;
	}
	
	public boolean getWinner() {
		return this.winner;
	}
	
	public boolean getFieldFull() {
		return this.fieldFull;
	}
	
	public void resetTileLeft() {
		this.isTileLeft = true;
	}
	
	
	public Tile[][] getTile() {
		return this.tiles;
	}
}
         