import java.util.Scanner;

public class MyScanner {

	private Scanner scanner = new Scanner(System.in);
	
	// insert validation process
	 public String scanForText() {
		 return this.scanner.nextLine();
	 }
	 
	 public char getChar() {
		 return scanner.next().toLowerCase().charAt(0);
	 }
	 
	 public  void validateNumber(int number) {
		 
		    do {
		        while (!this.scanner.hasNextInt()) {
		            this.scanner.next();
		        }
		        number = this.scanner.nextInt();
		    } while (number >= 7);
	 }
//	 
//	 public  void validateNumberRotation() {
//		 int number;
//		    do {
//		        while (!this.scanner.hasNextInt()) {
//		            System.out.println("invalid number");
//		            this.scanner.next();
//		        }
//		        number = this.scanner.nextInt();
//		    } while (number <= 0);
//		    this.rotation=number;
//	 }

}
