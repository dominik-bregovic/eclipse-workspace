public class ConnectFour {
	public static void main(String[] args) {
		System.out.println("\n===Connect Four===");
		Game game = new Game();
	}
}
// ask for the three spaces after entering a row and printing game