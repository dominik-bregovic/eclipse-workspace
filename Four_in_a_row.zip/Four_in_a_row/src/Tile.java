
public class Tile {
	
	private Disc disc;
	
	public Disc getTileDisc() {
		return this.disc;
	}
	
	public void setTileDisc(Disc playersDisc) {
		this.disc = playersDisc;
	}
}
