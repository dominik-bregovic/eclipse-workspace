I rounded the numbers up like in our the given example.

From Dominik Bregovic.
